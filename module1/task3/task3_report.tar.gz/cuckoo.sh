#!/bin/bash

PIPE_DIR="/tmp/run"
PIPE="$PIPE_DIR/cuckoo.pid"
LOGFILE="$PWD/cuckoo.log"

mkdir -p "$PIPE_DIR"
rm -f "$PIPE"
mkfifo "$PIPE"

log_msg() {
	echo "$(date '+%F %T') $1" >> "$LOGFILE"
}

shutdown() {
	log_msg "Shutdown!"
	rm -f "$PIPE"
	exit 0
}

trap shutdown SIGTERM

log_msg "Startup!"

exec 3<>"$PIPE"

while true; do
	if read -r line <&3; then
		if [[ "$line" =~ ^([A-Za-z0-9._-]+)\[([0-9]+)\]:[[:space:]]how[[:space:]]much[[:space:]]time[[:space:]]do[[:space:]]I[[:space:]]have\?$ ]]; then
			name="${BASH_REMATCH[1]}"
			pid="${BASH_REMATCH[2]}"
			n=$((RANDOM % 9 + 2))
			log_msg "$name[$pid] $n"
		fi
	fi
done

