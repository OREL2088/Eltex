#!/bin/bash

SCRIPT_NAME="$(basename "$0")"
PID="$$"
REPORT_FILE="$PWD/report_${SCRIPT_NAME}.log"
CUCKOO_PIPE="/tmp/run/cuckoo.pid"
CUCKOO_LOG="$PWD/cuckoo.log"

log_msg() {
	echo "$(date '+%F %T') [$PID] $1" >> "$REPORT_FILE"
}

if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
	echo "я бригадир, сам не работаю"
	exit 0
fi

log_msg "Скрипт запущен"

REQUEST="${SCRIPT_NAME}[$PID]: how much time do I have?"
echo "$REQUEST" > "$CUCKOO_PIPE"

N=""
while true; do
	N=$(awk -v target="${SCRIPT_NAME}[$PID]" '$3 == target {print $4}' "$CUCKOO_LOG" | tail -n 1)
	if [[ "$N" =~ ^[2-9]$|^10$ ]]; then
		break
	fi
	sleep 1
done

sleep "$N"

log_msg "Скрипт завершился, работал $N секунд."
